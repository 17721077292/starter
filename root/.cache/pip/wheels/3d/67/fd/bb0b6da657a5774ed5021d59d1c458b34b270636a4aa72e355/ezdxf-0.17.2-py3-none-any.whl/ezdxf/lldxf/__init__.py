# Low Level DXF modules
# Copyright (c) 2015-2020, Manfred Moitzi
# License: MIT License
