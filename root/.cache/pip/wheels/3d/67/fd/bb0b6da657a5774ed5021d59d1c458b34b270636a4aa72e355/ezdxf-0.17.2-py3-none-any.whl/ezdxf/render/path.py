# Dummy file
# features of v0.15.1
from ezdxf.path import Path, Command
import warnings

warnings.warn(
    'Import class Path() only from ezdxf.path, ezdxf.render.path.py will be '
    'removed in v0.17.', DeprecationWarning)
